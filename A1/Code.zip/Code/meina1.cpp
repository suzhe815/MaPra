/***********************************************************
 *  Name       : meina1.cpp                                *
 *  Verwendung : Loesung der ersten Praktikumsaufgabe,     *
 *               Nullstellen eines quadratischen Polynoms  *
 *  Autor      :                                           *
 *  Datum      :                                           *
 *  Sprache    : C++                                       *
 ***********************************************************/

// Einbinden der Praktikums-Umgebung. Falls Sie die Ein-/Ausgabe zuerst
// nicht ueber die Praktikumsumgebung machen wollen, sollten Sie auch noch
// #include <iostream> einbinden.

#include "unit.h"

// ===== Hauptprogramm =====

int main() {
    // Hier kommt nun Ihr Programm. Viel Erfolg!

    return 0;
}
